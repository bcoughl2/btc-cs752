var Montage = require("montage/core/core").Montage,
    AbstractToggleSwitch = require("montage/ui/base/abstract-toggle-switch").AbstractToggleSwitch;

exports.ToggleSwitch = AbstractToggleSwitch.specialize({ });
