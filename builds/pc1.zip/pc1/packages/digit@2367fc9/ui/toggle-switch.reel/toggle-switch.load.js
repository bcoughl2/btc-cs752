montageDefine("2367fc9","ui/toggle-switch.reel/toggle-switch",{dependencies:["montage/core/core","montage/ui/base/abstract-toggle-switch"],factory:function(require,exports,module){var Montage = require("montage/core/core").Montage,
    AbstractToggleSwitch = require("montage/ui/base/abstract-toggle-switch").AbstractToggleSwitch;

exports.ToggleSwitch = AbstractToggleSwitch.specialize({ });

}})