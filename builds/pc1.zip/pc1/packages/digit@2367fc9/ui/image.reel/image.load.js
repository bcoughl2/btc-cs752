montageDefine("2367fc9","ui/image.reel/image",{dependencies:["montage/ui/base/abstract-image"],factory:function(require,exports,module){/**
 * @module "digit/ui/image.reel"
 */
var AbstractImage = require("montage/ui/base/abstract-image").AbstractImage;
/**
 * @class Image
 * @extends external:AbstractImage
 */
exports.Image = AbstractImage.specialize(/** @lends Image */ {

});

}})