montageDefine("a9d4b97","tests/21-conditional_comments.json",{exports: {
  "name": "Conditional comments",
  "options": {
    "handler": {},
    "parser": {}
  },
  "html": "<!--[if lt IE 7]> <html class='no-js ie6 oldie' lang='en'> <![endif]--><!--[if lt IE 7]> <html class='no-js ie6 oldie' lang='en'> <![endif]-->",
  "expected": [
    {
      "data": "[if lt IE 7]> <html class='no-js ie6 oldie' lang='en'> <![endif]",
      "type": "comment"
    },
    {
      "data": "[if lt IE 7]> <html class='no-js ie6 oldie' lang='en'> <![endif]",
      "type": "comment"
    }
  ]
}})