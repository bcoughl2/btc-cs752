montageDefine("a9d4b97","tests/20-template_script_tags.json",{exports: {
  "name": "Template script tags",
  "options": {
    "handler": {},
    "parser": {}
  },
  "html": "<script type=\"text/template\"><h1>Heading1</h1></script>",
  "expected": [
    {
      "type": "script",
      "name": "script",
      "attribs": {
        "type": "text/template"
      },
      "children": [
        {
          "data": "<h1>Heading1</h1>",
          "type": "text"
        }
      ]
    }
  ]
}})