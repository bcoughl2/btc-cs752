montageDefine("a9d4b97","tests/12-text_only.json",{exports: {
  "name": "Only text",
  "options": {
    "handler": {},
    "parser": {}
  },
  "html": "this is the text",
  "expected": [
    {
      "data": "this is the text",
      "type": "text"
    }
  ]
}})