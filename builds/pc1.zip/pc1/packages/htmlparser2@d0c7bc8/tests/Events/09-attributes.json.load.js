montageDefine("d0c7bc8","tests/Events/09-attributes.json",{exports: {
  "name": "attributes (no white space, no value, no quotes)",
  "options": {
    "handler": {},
    "parser": {}
  },
  "html": "<button class=\"test0\"title=\"test1\" disabled value=test2>adsf</button>",
  "expected": [
    {
      "event": "opentagname",
      "data": [
        "button"
      ]
    },
    {
      "event": "attribute",
      "data": [
        "class",
        "test0"
      ]
    },
    {
      "event": "attribute",
      "data": [
        "title",
        "test1"
      ]
    },
    {
      "event": "attribute",
      "data": [
        "disabled",
        ""
      ]
    },
    {
      "event": "attribute",
      "data": [
        "value",
        "test2"
      ]
    },
    {
      "event": "opentag",
      "data": [
        "button",
        {
          "class": "test0",
          "title": "test1",
          "disabled": "",
          "value": "test2"
        }
      ]
    },
    {
      "event": "text",
      "data": [
        "adsf"
      ]
    },
    {
      "event": "closetag",
      "data": [
        "button"
      ]
    }
  ]
}})