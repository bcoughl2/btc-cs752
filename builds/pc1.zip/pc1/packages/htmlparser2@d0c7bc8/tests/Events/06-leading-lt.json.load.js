montageDefine("d0c7bc8","tests/Events/06-leading-lt.json",{exports: {
  "name": "leading lt",
  "options": {
    "handler": {},
    "parser": {}
  },
  "html": ">a>",
  "expected": [
    {
      "event": "text",
      "data": [
        ">a>"
      ]
    }
  ]
}})