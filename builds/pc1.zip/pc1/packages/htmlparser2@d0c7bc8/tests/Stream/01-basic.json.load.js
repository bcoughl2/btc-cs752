montageDefine("d0c7bc8","tests/Stream/01-basic.json",{exports: {
  "name": "Basic html",
  "options": {},
  "file": "/Documents/Basic.html",
  "expected": [
    {
      "event": "processinginstruction",
      "data": [
        "!DOCTYPE",
        "!DOCTYPE html"
      ]
    },
    {
      "event": "opentagname",
      "data": [
        "html"
      ]
    },
    {
      "event": "opentag",
      "data": [
        "html",
        {}
      ]
    },
    {
      "event": "opentagname",
      "data": [
        "title"
      ]
    },
    {
      "event": "opentag",
      "data": [
        "title",
        {}
      ]
    },
    {
      "event": "text",
      "data": [
        "The Title"
      ]
    },
    {
      "event": "closetag",
      "data": [
        "title"
      ]
    },
    {
      "event": "opentagname",
      "data": [
        "body"
      ]
    },
    {
      "event": "opentag",
      "data": [
        "body",
        {}
      ]
    },
    {
      "event": "text",
      "data": [
        "Hello world"
      ]
    },
    {
      "event": "closetag",
      "data": [
        "body"
      ]
    },
    {
      "event": "closetag",
      "data": [
        "html"
      ]
    }
  ]
}})