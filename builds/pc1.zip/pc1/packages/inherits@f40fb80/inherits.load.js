montageDefine("f40fb80","inherits",{dependencies:["util"],factory:function(require,exports,module){module.exports = require('util').inherits

}})