montageDefine("b17cee3","shim",{dependencies:["./shim-array","./shim-object","./shim-function","./shim-regexp"],factory:function(require,exports,module){
var Array = require("./shim-array");
var Object = require("./shim-object");
var Function = require("./shim-function");
var RegExp = require("./shim-regexp");


}})