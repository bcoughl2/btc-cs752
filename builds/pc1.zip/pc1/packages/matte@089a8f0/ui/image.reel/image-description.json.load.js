montageDefine("089a8f0","ui/image.reel/image-description.json",{exports: {
    "image_description_alt":{
        "prototype":"ui/component-description[ComponentPropertyDescription]",
        "properties":{
            "_componentDescription":{
                "@":"root"
            },
            "_name":"alt",
            "_valueType":"string",
            "helpString":"Alternative text to be displayed if the image is not available to the user"
        }
    },

    "image_description_src":{
        "prototype":"ui/component-description[ComponentPropertyDescription]",
        "properties":{
            "_componentDescription":{
                "@":"root"
            },
            "_name":"src",
            "_valueType":"file",
            "helpString":"The image resource to display"
        }
    },

    "image_description_width":{
        "prototype":"ui/component-description[ComponentPropertyDescription]",
        "properties":{
            "_componentDescription":{
                "@":"root"
            },
            "_name":"width",
            "_valueType":"number",
            "helpString":"The rendered width of the image in CSS pixels"
        }
    },

    "image_description_height":{
        "prototype":"ui/component-description[ComponentPropertyDescription]",
        "properties":{
            "_componentDescription":{
                "@":"root"
            },
            "_name":"height",
            "_valueType":"number",
            "helpString":"The rendered height of the image in CSS pixels"
        }
    },

    "root":{
        "prototype":"ui/component-description",
        "properties":{
            "_componentPropertyDescriptions":{
                "alt":{
                    "@":"image_description_alt"
                },
                "src":{
                    "@":"image_description_src"
                },
                "width":{
                    "@":"image_description_width"
                },
                "height":{
                    "@":"image_description_height"
                }
            },
            "_componentPropertyDescriptionGroups":{
                "base":[
                    {
                        "@":"image_description_alt"
                    },
                    {
                        "@":"image_description_src"
                    },
                    {
                        "@":"image_description_width"
                    },
                    {
                        "@":"image_description_height"
                    }
                ]
            },
            "_componentPropertyValidationRules":{
            }
        }
    }
}
})