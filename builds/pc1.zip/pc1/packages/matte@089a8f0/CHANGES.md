### 0.1.4

 - Update native dependency to v0.1.3
   - Updated blueprints
   - Dispatch an action event when the select.reel is changed by the user
 - Fix confirm.reel buttons taking given values
 - Add video-player.reel

### 0.1.3

 - Stop re-establishing bindings in list so `contentController` or `content`
   can be set multiple times
