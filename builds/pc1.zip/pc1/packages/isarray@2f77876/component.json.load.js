montageDefine("2f77876","component.json",{exports: {
  "name" : "isarray",
  "description" : "Array#isArray for older browsers",
  "version" : "0.0.1",
  "repository" : "juliangruber/isarray",
  "homepage": "https://github.com/juliangruber/isarray",
  "main" : "index.js",
  "scripts" : [
    "index.js"
  ],
  "dependencies" : {},
  "keywords": ["browser","isarray","array"],
  "author": {
    "name": "Julian Gruber",
    "email": "mail@juliangruber.com",
    "url": "http://juliangruber.com"
  },
  "license": "MIT"
}
})