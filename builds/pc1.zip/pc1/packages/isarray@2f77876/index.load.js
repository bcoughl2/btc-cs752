montageDefine("2f77876","index",{dependencies:[],factory:function(require,exports,module){module.exports = Array.isArray || function (arr) {
  return Object.prototype.toString.call(arr) == '[object Array]';
};

}})