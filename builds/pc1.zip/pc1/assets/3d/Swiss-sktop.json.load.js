montageDefine("57c24ba","assets/3d/Swiss-sktop.json",{exports: {
    "accessors": {
        "accessor_100": {
            "bufferView": "bufferView_663",
            "byteOffset": 102756,
            "byteStride": 12,
            "count": 415,
            "max": [
                1,
                1,
                0.999914
            ],
            "min": [
                -1,
                -1,
                -0.999907
            ],
            "type": 35665
        },
        "accessor_116": {
            "bufferView": "bufferView_662",
            "byteOffset": 18582,
            "byteStride": 0,
            "count": 360,
            "type": 5123
        },
        "accessor_118": {
            "bufferView": "bufferView_663",
            "byteOffset": 107736,
            "byteStride": 12,
            "count": 240,
            "max": [
                896.379,
                124.075,
                100
            ],
            "min": [
                -3.05e-05,
                117,
                -94.6526
            ],
            "type": 35665
        },
        "accessor_120": {
            "bufferView": "bufferView_663",
            "byteOffset": 110616,
            "byteStride": 12,
            "count": 240,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999861
            ],
            "type": 35665
        },
        "accessor_136": {
            "bufferView": "bufferView_662",
            "byteOffset": 19302,
            "byteStride": 0,
            "count": 438,
            "type": 5123
        },
        "accessor_138": {
            "bufferView": "bufferView_663",
            "byteOffset": 113496,
            "byteStride": 12,
            "count": 317,
            "max": [
                896.379,
                38,
                100
            ],
            "min": [
                -3.05e-05,
                30.525,
                -100
            ],
            "type": 35665
        },
        "accessor_140": {
            "bufferView": "bufferView_663",
            "byteOffset": 117300,
            "byteStride": 12,
            "count": 317,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_156": {
            "bufferView": "bufferView_662",
            "byteOffset": 21030,
            "byteStride": 0,
            "count": 468,
            "type": 5123
        },
        "accessor_158": {
            "bufferView": "bufferView_663",
            "byteOffset": 125688,
            "byteStride": 12,
            "count": 321,
            "max": [
                896.379,
                94,
                90.9245
            ],
            "min": [
                -3.05e-05,
                86.2875,
                -100
            ],
            "type": 35665
        },
        "accessor_16": {
            "bufferView": "bufferView_662",
            "byteOffset": 20178,
            "byteStride": 0,
            "count": 426,
            "type": 5123
        },
        "accessor_160": {
            "bufferView": "bufferView_663",
            "byteOffset": 129540,
            "byteStride": 12,
            "count": 321,
            "max": [
                1,
                1,
                0.999642
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_176": {
            "bufferView": "bufferView_662",
            "byteOffset": 21966,
            "byteStride": 0,
            "count": 192,
            "type": 5123
        },
        "accessor_178": {
            "bufferView": "bufferView_663",
            "byteOffset": 133392,
            "byteStride": 12,
            "count": 127,
            "max": [
                163,
                102,
                90.9245
            ],
            "min": [
                -3.05e-05,
                94.675,
                -53
            ],
            "type": 35665
        },
        "accessor_18": {
            "bufferView": "bufferView_663",
            "byteOffset": 121104,
            "byteStride": 12,
            "count": 191,
            "max": [
                876.97,
                116.408,
                132.351
            ],
            "min": [
                67.9995,
                93.7637,
                -26.5567
            ],
            "type": 35665
        },
        "accessor_180": {
            "bufferView": "bufferView_663",
            "byteOffset": 134916,
            "byteStride": 12,
            "count": 127,
            "max": [
                1,
                1,
                0.923879
            ],
            "min": [
                -1,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_196": {
            "bufferView": "bufferView_662",
            "byteOffset": 22350,
            "byteStride": 0,
            "count": 438,
            "type": 5123
        },
        "accessor_198": {
            "bufferView": "bufferView_663",
            "byteOffset": 136440,
            "byteStride": 12,
            "count": 317,
            "max": [
                896.379,
                68,
                100
            ],
            "min": [
                -3.05e-05,
                60.525,
                -100
            ],
            "type": 35665
        },
        "accessor_20": {
            "bufferView": "bufferView_663",
            "byteOffset": 123396,
            "byteStride": 12,
            "count": 191,
            "max": [
                0.992546,
                1,
                0.999996
            ],
            "min": [
                -1,
                -1,
                -0.999991
            ],
            "type": 35665
        },
        "accessor_200": {
            "bufferView": "bufferView_663",
            "byteOffset": 140244,
            "byteStride": 12,
            "count": 317,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_216": {
            "bufferView": "bufferView_662",
            "byteOffset": 23226,
            "byteStride": 0,
            "count": 3948,
            "type": 5123
        },
        "accessor_218": {
            "bufferView": "bufferView_663",
            "byteOffset": 144048,
            "byteStride": 12,
            "count": 689,
            "max": [
                17.2418,
                101.199,
                -66.6692
            ],
            "min": [
                -60.4237,
                -1.82844,
                -144.31
            ],
            "type": 35665
        },
        "accessor_220": {
            "bufferView": "bufferView_663",
            "byteOffset": 152316,
            "byteStride": 12,
            "count": 689,
            "max": [
                0.980769,
                0.997669,
                0.98679
            ],
            "min": [
                -0.984933,
                -0.997669,
                -0.983619
            ],
            "type": 35665
        },
        "accessor_236": {
            "bufferView": "bufferView_662",
            "byteOffset": 31122,
            "byteStride": 0,
            "count": 300,
            "type": 5123
        },
        "accessor_238": {
            "bufferView": "bufferView_663",
            "byteOffset": 160584,
            "byteStride": 12,
            "count": 245,
            "max": [
                711,
                -0.102995,
                45
            ],
            "min": [
                601,
                -0.103014,
                -45
            ],
            "type": 35665
        },
        "accessor_240": {
            "bufferView": "bufferView_663",
            "byteOffset": 163524,
            "byteStride": 12,
            "count": 245,
            "max": [
                8.7e-06,
                -1,
                9.1e-06
            ],
            "min": [
                -1.2e-06,
                -1,
                -3e-06
            ],
            "type": 35665
        },
        "accessor_256": {
            "bufferView": "bufferView_662",
            "byteOffset": 31722,
            "byteStride": 0,
            "count": 153,
            "type": 5123
        },
        "accessor_258": {
            "bufferView": "bufferView_663",
            "byteOffset": 166464,
            "byteStride": 12,
            "count": 86,
            "max": [
                309.6,
                -0.114306,
                -6.02589
            ],
            "min": [
                284.509,
                -0.114309,
                -33.0015
            ],
            "type": 35665
        },
        "accessor_260": {
            "bufferView": "bufferView_663",
            "byteOffset": 167496,
            "byteStride": 12,
            "count": 86,
            "max": [
                1e-07,
                -1,
                0
            ],
            "min": [
                -8e-07,
                -1,
                -9e-07
            ],
            "type": 35665
        },
        "accessor_276": {
            "bufferView": "bufferView_662",
            "byteOffset": 0,
            "byteStride": 0,
            "count": 33,
            "type": 5123
        },
        "accessor_278": {
            "bufferView": "bufferView_663",
            "byteOffset": 0,
            "byteStride": 12,
            "count": 30,
            "max": [
                338.005,
                -0.114307,
                -5.99573
            ],
            "min": [
                309.684,
                -0.114311,
                -32.839
            ],
            "type": 35665
        },
        "accessor_280": {
            "bufferView": "bufferView_663",
            "byteOffset": 360,
            "byteStride": 12,
            "count": 30,
            "max": [
                8e-07,
                -1,
                1e-07
            ],
            "min": [
                -6e-07,
                -1,
                -4e-07
            ],
            "type": 35665
        },
        "accessor_296": {
            "bufferView": "bufferView_662",
            "byteOffset": 66,
            "byteStride": 0,
            "count": 30,
            "type": 5123
        },
        "accessor_298": {
            "bufferView": "bufferView_663",
            "byteOffset": 720,
            "byteStride": 12,
            "count": 29,
            "max": [
                374.646,
                -0.114307,
                -5.9957
            ],
            "min": [
                339.98,
                -0.114315,
                -32.9598
            ],
            "type": 35665
        },
        "accessor_300": {
            "bufferView": "bufferView_663",
            "byteOffset": 1068,
            "byteStride": 12,
            "count": 29,
            "max": [
                4e-07,
                -1,
                0
            ],
            "min": [
                -6e-07,
                -1,
                -6e-07
            ],
            "type": 35665
        },
        "accessor_316": {
            "bufferView": "bufferView_662",
            "byteOffset": 126,
            "byteStride": 0,
            "count": 78,
            "type": 5123
        },
        "accessor_318": {
            "bufferView": "bufferView_663",
            "byteOffset": 1416,
            "byteStride": 12,
            "count": 41,
            "max": [
                402.925,
                -0.114309,
                -5.99573
            ],
            "min": [
                379.184,
                -0.114315,
                -32.839
            ],
            "type": 35665
        },
        "accessor_320": {
            "bufferView": "bufferView_663",
            "byteOffset": 1908,
            "byteStride": 12,
            "count": 41,
            "max": [
                1.3e-06,
                -1,
                0
            ],
            "min": [
                -5.89e-05,
                -1,
                -2e-06
            ],
            "type": 35665
        },
        "accessor_336": {
            "bufferView": "bufferView_662",
            "byteOffset": 282,
            "byteStride": 0,
            "count": 24,
            "type": 5123
        },
        "accessor_338": {
            "bufferView": "bufferView_663",
            "byteOffset": 2400,
            "byteStride": 12,
            "count": 24,
            "max": [
                445.954,
                -0.114311,
                -5.9957
            ],
            "min": [
                417.969,
                -0.114317,
                -32.839
            ],
            "type": 35665
        },
        "accessor_340": {
            "bufferView": "bufferView_663",
            "byteOffset": 2688,
            "byteStride": 12,
            "count": 24,
            "max": [
                6e-07,
                -1,
                -1e-07
            ],
            "min": [
                -4e-07,
                -1,
                -6e-07
            ],
            "type": 35665
        },
        "accessor_356": {
            "bufferView": "bufferView_662",
            "byteOffset": 330,
            "byteStride": 0,
            "count": 150,
            "type": 5123
        },
        "accessor_358": {
            "bufferView": "bufferView_663",
            "byteOffset": 2976,
            "byteStride": 12,
            "count": 82,
            "max": [
                475.288,
                -0.114315,
                -5.89736
            ],
            "min": [
                449.704,
                -0.114319,
                -32.9359
            ],
            "type": 35665
        },
        "accessor_36": {
            "bufferView": "bufferView_662",
            "byteOffset": 4434,
            "byteStride": 0,
            "count": 402,
            "type": 5123
        },
        "accessor_360": {
            "bufferView": "bufferView_663",
            "byteOffset": 3960,
            "byteStride": 12,
            "count": 82,
            "max": [
                3e-07,
                -1,
                0
            ],
            "min": [
                -3e-07,
                -1,
                -8e-07
            ],
            "type": 35665
        },
        "accessor_376": {
            "bufferView": "bufferView_662",
            "byteOffset": 630,
            "byteStride": 0,
            "count": 246,
            "type": 5123
        },
        "accessor_378": {
            "bufferView": "bufferView_663",
            "byteOffset": 4944,
            "byteStride": 12,
            "count": 174,
            "max": [
                272,
                -0.1143,
                43.6852
            ],
            "min": [
                181,
                -0.114315,
                -32
            ],
            "type": 35665
        },
        "accessor_38": {
            "bufferView": "bufferView_663",
            "byteOffset": 31752,
            "byteStride": 12,
            "count": 175,
            "max": [
                567.998,
                115.667,
                114.256
            ],
            "min": [
                34.9992,
                102.632,
                -18.965
            ],
            "type": 35665
        },
        "accessor_380": {
            "bufferView": "bufferView_663",
            "byteOffset": 7032,
            "byteStride": 12,
            "count": 174,
            "max": [
                7e-06,
                -1,
                3.6e-06
            ],
            "min": [
                -4.1e-06,
                -1,
                -7.6e-06
            ],
            "type": 35665
        },
        "accessor_396": {
            "bufferView": "bufferView_662",
            "byteOffset": 1122,
            "byteStride": 0,
            "count": 6,
            "type": 5123
        },
        "accessor_398": {
            "bufferView": "bufferView_663",
            "byteOffset": 9120,
            "byteStride": 12,
            "count": 6,
            "max": [
                411.55,
                -0.114311,
                -5.9957
            ],
            "min": [
                407.789,
                -0.114317,
                -32.839
            ],
            "type": 35665
        },
        "accessor_40": {
            "bufferView": "bufferView_663",
            "byteOffset": 33852,
            "byteStride": 12,
            "count": 175,
            "max": [
                0.999992,
                1,
                0.999754
            ],
            "min": [
                -0.999687,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_400": {
            "bufferView": "bufferView_663",
            "byteOffset": 9192,
            "byteStride": 12,
            "count": 6,
            "max": [
                0,
                -1,
                -1e-07
            ],
            "min": [
                -5e-07,
                -1,
                -2e-07
            ],
            "type": 35665
        },
        "accessor_416": {
            "bufferView": "bufferView_662",
            "byteOffset": 1134,
            "byteStride": 0,
            "count": 630,
            "type": 5123
        },
        "accessor_418": {
            "bufferView": "bufferView_663",
            "byteOffset": 9264,
            "byteStride": 12,
            "count": 303,
            "max": [
                484,
                60.6546,
                -48.9999
            ],
            "min": [
                74,
                38.9219,
                -120
            ],
            "type": 35665
        },
        "accessor_420": {
            "bufferView": "bufferView_663",
            "byteOffset": 12900,
            "byteStride": 12,
            "count": 303,
            "max": [
                1,
                1,
                0.999541
            ],
            "min": [
                -0.963074,
                -1,
                -0.999472
            ],
            "type": 35665
        },
        "accessor_436": {
            "bufferView": "bufferView_662",
            "byteOffset": 2394,
            "byteStride": 0,
            "count": 1020,
            "type": 5123
        },
        "accessor_438": {
            "bufferView": "bufferView_663",
            "byteOffset": 16536,
            "byteStride": 12,
            "count": 634,
            "max": [
                882,
                85.6267,
                105
            ],
            "min": [
                35.0825,
                68.8232,
                -19
            ],
            "type": 35665
        },
        "accessor_440": {
            "bufferView": "bufferView_663",
            "byteOffset": 24144,
            "byteStride": 12,
            "count": 634,
            "max": [
                0.999957,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999999
            ],
            "type": 35665
        },
        "accessor_456": {
            "bufferView": "bufferView_662",
            "byteOffset": 5238,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_458": {
            "bufferView": "bufferView_663",
            "byteOffset": 35952,
            "byteStride": 12,
            "count": 98,
            "max": [
                842,
                133,
                22.6046
            ],
            "min": [
                822,
                21,
                2.60467
            ],
            "type": 35665
        },
        "accessor_460": {
            "bufferView": "bufferView_663",
            "byteOffset": 37128,
            "byteStride": 12,
            "count": 98,
            "max": [
                0.965929,
                1,
                0.965926
            ],
            "min": [
                -0.965929,
                -1,
                -0.965926
            ],
            "type": 35665
        },
        "accessor_476": {
            "bufferView": "bufferView_662",
            "byteOffset": 5526,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_478": {
            "bufferView": "bufferView_663",
            "byteOffset": 38304,
            "byteStride": 12,
            "count": 134,
            "max": [
                81,
                133,
                40
            ],
            "min": [
                61,
                21,
                20
            ],
            "type": 35665
        },
        "accessor_480": {
            "bufferView": "bufferView_663",
            "byteOffset": 39912,
            "byteStride": 12,
            "count": 134,
            "max": [
                0.965927,
                1,
                0.965926
            ],
            "min": [
                -0.965927,
                -1,
                -0.965928
            ],
            "type": 35665
        },
        "accessor_496": {
            "bufferView": "bufferView_662",
            "byteOffset": 5814,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_498": {
            "bufferView": "bufferView_663",
            "byteOffset": 41520,
            "byteStride": 12,
            "count": 111,
            "max": [
                471,
                133,
                -60
            ],
            "min": [
                451,
                21,
                -80.0002
            ],
            "type": 35665
        },
        "accessor_500": {
            "bufferView": "bufferView_663",
            "byteOffset": 42852,
            "byteStride": 12,
            "count": 111,
            "max": [
                0.96593,
                1,
                0.965926
            ],
            "min": [
                -0.96593,
                -1,
                -0.965927
            ],
            "type": 35665
        },
        "accessor_516": {
            "bufferView": "bufferView_662",
            "byteOffset": 6102,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_518": {
            "bufferView": "bufferView_663",
            "byteOffset": 44184,
            "byteStride": 12,
            "count": 111,
            "max": [
                580.784,
                133,
                -17.2157
            ],
            "min": [
                567.216,
                21,
                -30.7846
            ],
            "type": 35665
        },
        "accessor_520": {
            "bufferView": "bufferView_663",
            "byteOffset": 45516,
            "byteStride": 12,
            "count": 111,
            "max": [
                0.965929,
                1,
                0.965926
            ],
            "min": [
                -0.965933,
                -1,
                -0.965927
            ],
            "type": 35665
        },
        "accessor_536": {
            "bufferView": "bufferView_662",
            "byteOffset": 6390,
            "byteStride": 0,
            "count": 192,
            "type": 5123
        },
        "accessor_538": {
            "bufferView": "bufferView_663",
            "byteOffset": 46848,
            "byteStride": 12,
            "count": 131,
            "max": [
                870,
                116.659,
                -19.0001
            ],
            "min": [
                40,
                94.3591,
                -66
            ],
            "type": 35665
        },
        "accessor_540": {
            "bufferView": "bufferView_663",
            "byteOffset": 48420,
            "byteStride": 12,
            "count": 131,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_556": {
            "bufferView": "bufferView_662",
            "byteOffset": 6774,
            "byteStride": 0,
            "count": 624,
            "type": 5123
        },
        "accessor_558": {
            "bufferView": "bufferView_663",
            "byteOffset": 49992,
            "byteStride": 12,
            "count": 336,
            "max": [
                870,
                60.0005,
                -19.4418
            ],
            "min": [
                -6.134,
                38.4962,
                -89.7372
            ],
            "type": 35665
        },
        "accessor_56": {
            "bufferView": "bufferView_662",
            "byteOffset": 12942,
            "byteStride": 0,
            "count": 606,
            "type": 5123
        },
        "accessor_560": {
            "bufferView": "bufferView_663",
            "byteOffset": 54024,
            "byteStride": 12,
            "count": 336,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_576": {
            "bufferView": "bufferView_662",
            "byteOffset": 8022,
            "byteStride": 0,
            "count": 420,
            "type": 5123
        },
        "accessor_578": {
            "bufferView": "bufferView_663",
            "byteOffset": 58056,
            "byteStride": 12,
            "count": 262,
            "max": [
                896.38,
                85.8985,
                47
            ],
            "min": [
                39.0001,
                68.5375,
                -100
            ],
            "type": 35665
        },
        "accessor_58": {
            "bufferView": "bufferView_663",
            "byteOffset": 83232,
            "byteStride": 12,
            "count": 284,
            "max": [
                473.564,
                60.062,
                125.258
            ],
            "min": [
                42,
                38.5,
                -34.4626
            ],
            "type": 35665
        },
        "accessor_580": {
            "bufferView": "bufferView_663",
            "byteOffset": 61200,
            "byteStride": 12,
            "count": 262,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_596": {
            "bufferView": "bufferView_662",
            "byteOffset": 8862,
            "byteStride": 0,
            "count": 258,
            "type": 5123
        },
        "accessor_598": {
            "bufferView": "bufferView_663",
            "byteOffset": 64344,
            "byteStride": 12,
            "count": 116,
            "max": [
                67.8099,
                30.1709,
                -23.7172
            ],
            "min": [
                4.81924,
                5.35e-05,
                -58.0517
            ],
            "type": 35665
        },
        "accessor_60": {
            "bufferView": "bufferView_663",
            "byteOffset": 86640,
            "byteStride": 12,
            "count": 284,
            "max": [
                0.999962,
                1,
                0.999881
            ],
            "min": [
                -0.999962,
                -1,
                -0.999762
            ],
            "type": 35665
        },
        "accessor_600": {
            "bufferView": "bufferView_663",
            "byteOffset": 65736,
            "byteStride": 12,
            "count": 116,
            "max": [
                0.996547,
                1,
                0.996207
            ],
            "min": [
                -0.924274,
                -1,
                -0.996196
            ],
            "type": 35665
        },
        "accessor_616": {
            "bufferView": "bufferView_662",
            "byteOffset": 9378,
            "byteStride": 0,
            "count": 180,
            "type": 5123
        },
        "accessor_618": {
            "bufferView": "bufferView_663",
            "byteOffset": 67128,
            "byteStride": 12,
            "count": 127,
            "max": [
                542.806,
                45.2273,
                19.4956
            ],
            "min": [
                31.5023,
                27.4832,
                -55.9644
            ],
            "type": 35665
        },
        "accessor_620": {
            "bufferView": "bufferView_663",
            "byteOffset": 68652,
            "byteStride": 12,
            "count": 127,
            "max": [
                0.907578,
                1,
                0.995805
            ],
            "min": [
                -0.995805,
                -1,
                -0.995805
            ],
            "type": 35665
        },
        "accessor_636": {
            "bufferView": "bufferView_662",
            "byteOffset": 9738,
            "byteStride": 0,
            "count": 180,
            "type": 5123
        },
        "accessor_638": {
            "bufferView": "bufferView_663",
            "byteOffset": 70176,
            "byteStride": 12,
            "count": 129,
            "max": [
                542.806,
                27.2358,
                19.4956
            ],
            "min": [
                31.5023,
                9.49172,
                -55.9644
            ],
            "type": 35665
        },
        "accessor_640": {
            "bufferView": "bufferView_663",
            "byteOffset": 71724,
            "byteStride": 12,
            "count": 129,
            "max": [
                0.907577,
                1,
                0.995805
            ],
            "min": [
                -0.995805,
                -1,
                -0.995805
            ],
            "type": 35665
        },
        "accessor_656": {
            "bufferView": "bufferView_662",
            "byteOffset": 10098,
            "byteStride": 0,
            "count": 1422,
            "type": 5123
        },
        "accessor_658": {
            "bufferView": "bufferView_663",
            "byteOffset": 73272,
            "byteStride": 12,
            "count": 415,
            "max": [
                896.379,
                30,
                100
            ],
            "min": [
                -9.16e-05,
                -3.66e-05,
                -100
            ],
            "type": 35665
        },
        "accessor_660": {
            "bufferView": "bufferView_663",
            "byteOffset": 78252,
            "byteStride": 12,
            "count": 415,
            "max": [
                1,
                1,
                0.999914
            ],
            "min": [
                -1,
                -1,
                -0.999907
            ],
            "type": 35665
        },
        "accessor_76": {
            "bufferView": "bufferView_662",
            "byteOffset": 14154,
            "byteStride": 0,
            "count": 792,
            "type": 5123
        },
        "accessor_78": {
            "bufferView": "bufferView_663",
            "byteOffset": 90048,
            "byteStride": 12,
            "count": 322,
            "max": [
                877.529,
                60.1002,
                119.956
            ],
            "min": [
                446.906,
                38.3163,
                -29.7362
            ],
            "type": 35665
        },
        "accessor_80": {
            "bufferView": "bufferView_663",
            "byteOffset": 93912,
            "byteStride": 12,
            "count": 322,
            "max": [
                0.993806,
                1,
                0.999748
            ],
            "min": [
                -0.999452,
                -1,
                -0.99904
            ],
            "type": 35665
        },
        "accessor_96": {
            "bufferView": "bufferView_662",
            "byteOffset": 15738,
            "byteStride": 0,
            "count": 1422,
            "type": 5123
        },
        "accessor_98": {
            "bufferView": "bufferView_663",
            "byteOffset": 97776,
            "byteStride": 12,
            "count": 415,
            "max": [
                896.379,
                30,
                100
            ],
            "min": [
                -9.16e-05,
                -3.66e-05,
                -100
            ],
            "type": 35665
        }
    },
    "animations": {},
    "asset": {
        "generator": "collada2gltf@484bc37fe4fa8c5974618e65b311e7b22be95381",
        "premultipliedAlpha": true,
        "profile": "WebGL 1.0.2",
        "version": 0.6
    },
    "bufferViews": {
        "bufferView_662": {
            "buffer": "Swiss-sktop",
            "byteLength": 32028,
            "byteOffset": 0,
            "target": 34963
        },
        "bufferView_663": {
            "buffer": "Swiss-sktop",
            "byteLength": 168528,
            "byteOffset": 32028,
            "target": 34962
        }
    },
    "buffers": {
        "Swiss-sktop": {
            "byteLength": 200556,
            "path": "Swiss-sktop.bin",
            "type": "arraybuffer"
        }
    },
    "materials": {
        "ID164": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        0.964706,
                        0.545098,
                        0,
                        1
                    ]
                }
            },
            "name": "GOLD_METAL1"
        },
        "ID212": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        0.360784,
                        0.360784,
                        0.360784,
                        1
                    ]
                }
            },
            "name": "GREY_PLASTIC1"
        },
        "ID42": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        1,
                        0,
                        0,
                        1
                    ]
                }
            },
            "name": "RED_PLASTIC1"
        },
        "ID8": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        1,
                        1,
                        1,
                        1
                    ]
                }
            },
            "name": "STAINLESS_METAL1"
        }
    },
    "meshes": {
        "ID102": {
            "name": "ID102",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_280",
                        "POSITION": "accessor_278"
                    },
                    "indices": "accessor_276",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID108": {
            "name": "ID108",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_300",
                        "POSITION": "accessor_298"
                    },
                    "indices": "accessor_296",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID114": {
            "name": "ID114",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_320",
                        "POSITION": "accessor_318"
                    },
                    "indices": "accessor_316",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID120": {
            "name": "ID120",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_340",
                        "POSITION": "accessor_338"
                    },
                    "indices": "accessor_336",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID126": {
            "name": "ID126",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_360",
                        "POSITION": "accessor_358"
                    },
                    "indices": "accessor_356",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID132": {
            "name": "ID132",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_380",
                        "POSITION": "accessor_378"
                    },
                    "indices": "accessor_376",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID138": {
            "name": "ID138",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_400",
                        "POSITION": "accessor_398"
                    },
                    "indices": "accessor_396",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID146": {
            "name": "ID146",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_420",
                        "POSITION": "accessor_418"
                    },
                    "indices": "accessor_416",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID154": {
            "name": "ID154",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_440",
                        "POSITION": "accessor_438"
                    },
                    "indices": "accessor_436",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID16": {
            "name": "ID16",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_40",
                        "POSITION": "accessor_38"
                    },
                    "indices": "accessor_36",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID162": {
            "name": "ID162",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_460",
                        "POSITION": "accessor_458"
                    },
                    "indices": "accessor_456",
                    "material": "ID164",
                    "primitive": 4
                }
            ]
        },
        "ID170": {
            "name": "ID170",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_480",
                        "POSITION": "accessor_478"
                    },
                    "indices": "accessor_476",
                    "material": "ID164",
                    "primitive": 4
                }
            ]
        },
        "ID176": {
            "name": "ID176",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_500",
                        "POSITION": "accessor_498"
                    },
                    "indices": "accessor_496",
                    "material": "ID164",
                    "primitive": 4
                }
            ]
        },
        "ID182": {
            "name": "ID182",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_520",
                        "POSITION": "accessor_518"
                    },
                    "indices": "accessor_516",
                    "material": "ID164",
                    "primitive": 4
                }
            ]
        },
        "ID190": {
            "name": "ID190",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_540",
                        "POSITION": "accessor_538"
                    },
                    "indices": "accessor_536",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID196": {
            "name": "ID196",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_560",
                        "POSITION": "accessor_558"
                    },
                    "indices": "accessor_556",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID202": {
            "name": "ID202",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_580",
                        "POSITION": "accessor_578"
                    },
                    "indices": "accessor_576",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID210": {
            "name": "ID210",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_600",
                        "POSITION": "accessor_598"
                    },
                    "indices": "accessor_596",
                    "material": "ID212",
                    "primitive": 4
                }
            ]
        },
        "ID218": {
            "name": "ID218",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_620",
                        "POSITION": "accessor_618"
                    },
                    "indices": "accessor_616",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID224": {
            "name": "ID224",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_640",
                        "POSITION": "accessor_638"
                    },
                    "indices": "accessor_636",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID232": {
            "name": "ID232",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_660",
                        "POSITION": "accessor_658"
                    },
                    "indices": "accessor_656",
                    "material": "ID42",
                    "primitive": 4
                }
            ]
        },
        "ID24": {
            "name": "ID24",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_60",
                        "POSITION": "accessor_58"
                    },
                    "indices": "accessor_56",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID32": {
            "name": "ID32",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_80",
                        "POSITION": "accessor_78"
                    },
                    "indices": "accessor_76",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID40": {
            "name": "ID40",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_100",
                        "POSITION": "accessor_98"
                    },
                    "indices": "accessor_96",
                    "material": "ID42",
                    "primitive": 4
                }
            ]
        },
        "ID50": {
            "name": "ID50",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_120",
                        "POSITION": "accessor_118"
                    },
                    "indices": "accessor_116",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID56": {
            "name": "ID56",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_140",
                        "POSITION": "accessor_138"
                    },
                    "indices": "accessor_136",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID6": {
            "name": "ID6",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_20",
                        "POSITION": "accessor_18"
                    },
                    "indices": "accessor_16",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID62": {
            "name": "ID62",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_160",
                        "POSITION": "accessor_158"
                    },
                    "indices": "accessor_156",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID68": {
            "name": "ID68",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_180",
                        "POSITION": "accessor_178"
                    },
                    "indices": "accessor_176",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID74": {
            "name": "ID74",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_200",
                        "POSITION": "accessor_198"
                    },
                    "indices": "accessor_196",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID82": {
            "name": "ID82",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_220",
                        "POSITION": "accessor_218"
                    },
                    "indices": "accessor_216",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID90": {
            "name": "ID90",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_240",
                        "POSITION": "accessor_238"
                    },
                    "indices": "accessor_236",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID96": {
            "name": "ID96",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_260",
                        "POSITION": "accessor_258"
                    },
                    "indices": "accessor_256",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        }
    },
    "nodes": {
        "ID14": {
            "children": [
                "ID15"
            ],
            "matrix": [
                0.865,
                0.499399,
                -0.0487418,
                0,
                -0.499993,
                0.86603,
                8.1e-06,
                0,
                0.0422159,
                0.0243636,
                0.998811,
                0,
                290.871,
                -383.28,
                -38.2665,
                1
            ],
            "name": "BLADE_SMALL"
        },
        "ID144": {
            "children": [
                "ID145"
            ],
            "matrix": [
                0.865919,
                0.499938,
                0.0157073,
                0,
                -0.5,
                0.866025,
                -1e-07,
                0,
                -0.013603,
                -0.0078536,
                0.999877,
                0,
                339.411,
                -355.256,
                50.6871,
                1
            ],
            "name": "REEMER"
        },
        "ID145": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID146"
            ],
            "name": "REEMER"
        },
        "ID15": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID16"
            ],
            "name": "BLADE_SMALL"
        },
        "ID152": {
            "children": [
                "ID153"
            ],
            "matrix": [
                0.858419,
                0.495605,
                0.132256,
                0,
                -0.499998,
                0.866027,
                6e-07,
                0,
                -0.114537,
                -0.0661284,
                0.991216,
                0,
                262.207,
                -399.02,
                -94.0762,
                1
            ],
            "name": "SAW"
        },
        "ID153": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID154"
            ],
            "name": "SAW"
        },
        "ID160": {
            "children": [
                "ID161"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_3"
        },
        "ID161": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID162",
                "ID170",
                "ID176",
                "ID182"
            ],
            "name": "SHAFTS"
        },
        "ID188": {
            "children": [
                "ID189"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_4"
        },
        "ID189": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID190",
                "ID196",
                "ID202"
            ],
            "name": "SPRINGS"
        },
        "ID2": {
            "children": [
                "ID3"
            ],
            "matrix": [
                0.923878,
                0.0015118,
                0.382683,
                0,
                0.382682,
                0.0008728,
                -0.92388,
                0,
                -0.0017307,
                0.999999,
                0.0002279,
                0,
                -157.484,
                270.458,
                -363.609,
                1
            ],
            "name": "Swiss_Army_Knife"
        },
        "ID208": {
            "children": [
                "ID209"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "TWEEZER"
        },
        "ID209": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID210",
                "ID218",
                "ID224"
            ],
            "name": "TWEEZER"
        },
        "ID22": {
            "children": [
                "ID23"
            ],
            "matrix": [
                0.854885,
                0.493568,
                0.159881,
                0,
                -0.5,
                0.866026,
                -1e-07,
                0,
                -0.138461,
                -0.0799404,
                0.987136,
                0,
                262.54,
                -399.638,
                -64.5054,
                1
            ],
            "name": "BOTTLE_OPENER"
        },
        "ID23": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID24"
            ],
            "name": "BOTTLE_OPENER"
        },
        "ID230": {
            "children": [
                "ID231"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                0.5,
                -0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                206.113,
                -254.305,
                0,
                1
            ],
            "name": "instance_5"
        },
        "ID231": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID232"
            ],
            "name": "COVERPLATE"
        },
        "ID3": {
            "children": [
                "ID4",
                "ID14",
                "ID22",
                "ID30",
                "ID38",
                "ID48",
                "ID80",
                "ID88",
                "ID144",
                "ID152",
                "ID160",
                "ID188",
                "ID208",
                "ID230"
            ],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "name": "Swiss_Army_Knife"
        },
        "ID30": {
            "children": [
                "ID31"
            ],
            "matrix": [
                0.864628,
                0.499193,
                -0.0567967,
                0,
                -0.5,
                0.866026,
                -2e-07,
                0,
                0.0491872,
                0.0283985,
                0.998386,
                0,
                280.808,
                -389.091,
                22.006,
                1
            ],
            "name": "CAN_OPENER"
        },
        "ID31": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID32"
            ],
            "name": "CAN_OPENER"
        },
        "ID38": {
            "children": [
                "ID39"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_0"
        },
        "ID39": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID40"
            ],
            "name": "COVERPLATE"
        },
        "ID4": {
            "children": [
                "ID5"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                270.068,
                -395.282,
                -25.9493,
                1
            ],
            "name": "BLADE_MAIN"
        },
        "ID48": {
            "children": [
                "ID49"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_1"
        },
        "ID49": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID50",
                "ID56",
                "ID62",
                "ID68",
                "ID74"
            ],
            "name": "DIVIDER"
        },
        "ID5": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID6"
            ],
            "name": "BLADE_MAIN"
        },
        "ID80": {
            "children": [
                "ID81"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "KEY_RING"
        },
        "ID81": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID82"
            ],
            "name": "KEY_RING"
        },
        "ID88": {
            "children": [
                "ID89"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_2"
        },
        "ID89": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID90",
                "ID96",
                "ID102",
                "ID108",
                "ID114",
                "ID120",
                "ID126",
                "ID132",
                "ID138"
            ],
            "name": "LOGO"
        },
        "node_0": {
            "children": [
                "ID2"
            ],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "name": "SketchUp"
        }
    },
    "programs": {
        "program_0": {
            "attributes": [
                "a_normal",
                "a_position"
            ],
            "fragmentShader": "Swiss-sktop0FS",
            "vertexShader": "Swiss-sktop0VS"
        }
    },
    "scene": "defaultScene",
    "scenes": {
        "defaultScene": {
            "nodes": [
                "node_0"
            ]
        }
    },
    "shaders": {
        "Swiss-sktop0FS": {
            "path": "Swiss-sktop0FS.glsl",
            "type": 35632
        },
        "Swiss-sktop0VS": {
            "path": "Swiss-sktop0VS.glsl",
            "type": 35633
        }
    },
    "skins": {},
    "techniques": {
        "technique0": {
            "parameters": {
                "diffuse": {
                    "type": 35666
                },
                "modelViewMatrix": {
                    "semantic": "MODELVIEW",
                    "type": 35676
                },
                "normal": {
                    "semantic": "NORMAL",
                    "type": 35665
                },
                "normalMatrix": {
                    "semantic": "MODELVIEWINVERSETRANSPOSE",
                    "type": 35675
                },
                "position": {
                    "semantic": "POSITION",
                    "type": 35665
                },
                "projectionMatrix": {
                    "semantic": "PROJECTION",
                    "type": 35676
                }
            },
            "pass": "defaultPass",
            "passes": {
                "defaultPass": {
                    "details": {
                        "commonProfile": {
                            "extras": {
                                "doubleSided": false
                            },
                            "lightingModel": "Lambert",
                            "parameters": [
                                "diffuse",
                                "modelViewMatrix",
                                "normalMatrix",
                                "projectionMatrix"
                            ]
                        },
                        "type": "COLLADA-1.4.1/commonProfile"
                    },
                    "instanceProgram": {
                        "attributes": {
                            "a_normal": "normal",
                            "a_position": "position"
                        },
                        "program": "program_0",
                        "uniforms": {
                            "u_diffuse": "diffuse",
                            "u_modelViewMatrix": "modelViewMatrix",
                            "u_normalMatrix": "normalMatrix",
                            "u_projectionMatrix": "projectionMatrix"
                        }
                    },
                    "states": {
                        "blendEnable": 0,
                        "cullFaceEnable": 1,
                        "depthMask": 1,
                        "depthTestEnable": 1
                    }
                }
            }
        }
    }
}})