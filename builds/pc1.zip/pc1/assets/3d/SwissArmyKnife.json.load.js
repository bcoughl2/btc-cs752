montageDefine("57c24ba","assets/3d/SwissArmyKnife.json",{exports: {
    "accessors": {
        "accessor_100": {
            "bufferView": "bufferView_484",
            "byteOffset": 26921,
            "byteStride": 12,
            "count": 415,
            "max": [
                1,
                1,
                0.999914
            ],
            "min": [
                -1,
                -1,
                -0.999907
            ],
            "type": 35665
        },
        "accessor_116": {
            "bufferView": "bufferView_484",
            "byteOffset": 21549,
            "byteStride": 0,
            "count": 360,
            "type": 5123
        },
        "accessor_118": {
            "bufferView": "bufferView_484",
            "byteOffset": 22269,
            "byteStride": 12,
            "count": 240,
            "max": [
                896.379,
                124.075,
                100
            ],
            "min": [
                -3.05e-05,
                117,
                -94.6526
            ],
            "type": 35665
        },
        "accessor_120": {
            "bufferView": "bufferView_484",
            "byteOffset": 25149,
            "byteStride": 12,
            "count": 240,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999861
            ],
            "type": 35665
        },
        "accessor_136": {
            "bufferView": "bufferView_484",
            "byteOffset": 23134,
            "byteStride": 0,
            "count": 438,
            "type": 5123
        },
        "accessor_138": {
            "bufferView": "bufferView_484",
            "byteOffset": 24010,
            "byteStride": 12,
            "count": 317,
            "max": [
                896.379,
                38,
                100
            ],
            "min": [
                -3.05e-05,
                30.525,
                -100
            ],
            "type": 35665
        },
        "accessor_140": {
            "bufferView": "bufferView_484",
            "byteOffset": 27814,
            "byteStride": 12,
            "count": 317,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_156": {
            "bufferView": "bufferView_484",
            "byteOffset": 26370,
            "byteStride": 0,
            "count": 468,
            "type": 5123
        },
        "accessor_158": {
            "bufferView": "bufferView_484",
            "byteOffset": 27306,
            "byteStride": 12,
            "count": 321,
            "max": [
                896.379,
                94,
                90.9245
            ],
            "min": [
                -3.05e-05,
                86.2875,
                -100
            ],
            "type": 35665
        },
        "accessor_16": {
            "bufferView": "bufferView_484",
            "byteOffset": 24966,
            "byteStride": 0,
            "count": 426,
            "type": 5123
        },
        "accessor_160": {
            "bufferView": "bufferView_484",
            "byteOffset": 31158,
            "byteStride": 12,
            "count": 321,
            "max": [
                1,
                1,
                0.999642
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_176": {
            "bufferView": "bufferView_484",
            "byteOffset": 28248,
            "byteStride": 0,
            "count": 192,
            "type": 5123
        },
        "accessor_178": {
            "bufferView": "bufferView_484",
            "byteOffset": 28632,
            "byteStride": 12,
            "count": 127,
            "max": [
                163,
                102,
                90.9245
            ],
            "min": [
                -3.05e-05,
                94.675,
                -53
            ],
            "type": 35665
        },
        "accessor_18": {
            "bufferView": "bufferView_484",
            "byteOffset": 25818,
            "byteStride": 12,
            "count": 191,
            "max": [
                876.97,
                116.408,
                132.351
            ],
            "min": [
                67.9995,
                93.7637,
                -26.5567
            ],
            "type": 35665
        },
        "accessor_180": {
            "bufferView": "bufferView_484",
            "byteOffset": 30156,
            "byteStride": 12,
            "count": 127,
            "max": [
                1,
                1,
                0.923879
            ],
            "min": [
                -1,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_196": {
            "bufferView": "bufferView_484",
            "byteOffset": 29344,
            "byteStride": 0,
            "count": 438,
            "type": 5123
        },
        "accessor_198": {
            "bufferView": "bufferView_484",
            "byteOffset": 30220,
            "byteStride": 12,
            "count": 317,
            "max": [
                896.379,
                68,
                100
            ],
            "min": [
                -3.05e-05,
                60.525,
                -100
            ],
            "type": 35665
        },
        "accessor_20": {
            "bufferView": "bufferView_484",
            "byteOffset": 28110,
            "byteStride": 12,
            "count": 191,
            "max": [
                0.992546,
                1,
                0.999996
            ],
            "min": [
                -1,
                -1,
                -0.999991
            ],
            "type": 35665
        },
        "accessor_200": {
            "bufferView": "bufferView_484",
            "byteOffset": 34024,
            "byteStride": 12,
            "count": 317,
            "max": [
                1,
                1,
                0.999907
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_216": {
            "bufferView": "bufferView_484",
            "byteOffset": 31179,
            "byteStride": 0,
            "count": 3948,
            "type": 5123
        },
        "accessor_218": {
            "bufferView": "bufferView_484",
            "byteOffset": 39075,
            "byteStride": 12,
            "count": 689,
            "max": [
                17.2418,
                101.199,
                -66.6692
            ],
            "min": [
                -60.4237,
                -1.82844,
                -144.31
            ],
            "type": 35665
        },
        "accessor_220": {
            "bufferView": "bufferView_484",
            "byteOffset": 47343,
            "byteStride": 12,
            "count": 689,
            "max": [
                0.980769,
                0.997669,
                0.98679
            ],
            "min": [
                -0.984933,
                -0.997669,
                -0.983619
            ],
            "type": 35665
        },
        "accessor_236": {
            "bufferView": "bufferView_484",
            "byteOffset": 35046,
            "byteStride": 0,
            "count": 630,
            "type": 5123
        },
        "accessor_238": {
            "bufferView": "bufferView_484",
            "byteOffset": 36306,
            "byteStride": 12,
            "count": 303,
            "max": [
                484,
                60.6546,
                -48.9999
            ],
            "min": [
                74,
                38.9219,
                -120
            ],
            "type": 35665
        },
        "accessor_240": {
            "bufferView": "bufferView_484",
            "byteOffset": 39942,
            "byteStride": 12,
            "count": 303,
            "max": [
                1,
                1,
                0.999541
            ],
            "min": [
                -0.963074,
                -1,
                -0.999472
            ],
            "type": 35665
        },
        "accessor_256": {
            "bufferView": "bufferView_484",
            "byteOffset": 37029,
            "byteStride": 0,
            "count": 1020,
            "type": 5123
        },
        "accessor_258": {
            "bufferView": "bufferView_484",
            "byteOffset": 39069,
            "byteStride": 12,
            "count": 634,
            "max": [
                882,
                85.6267,
                105
            ],
            "min": [
                35.0825,
                68.8232,
                -19
            ],
            "type": 35665
        },
        "accessor_260": {
            "bufferView": "bufferView_484",
            "byteOffset": 46677,
            "byteStride": 12,
            "count": 634,
            "max": [
                0.999957,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999999
            ],
            "type": 35665
        },
        "accessor_276": {
            "bufferView": "bufferView_484",
            "byteOffset": 0,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_278": {
            "bufferView": "bufferView_484",
            "byteOffset": 288,
            "byteStride": 12,
            "count": 98,
            "max": [
                842,
                133,
                22.6046
            ],
            "min": [
                822,
                21,
                2.60467
            ],
            "type": 35665
        },
        "accessor_280": {
            "bufferView": "bufferView_484",
            "byteOffset": 1464,
            "byteStride": 12,
            "count": 98,
            "max": [
                0.965929,
                1,
                0.965926
            ],
            "min": [
                -0.965929,
                -1,
                -0.965926
            ],
            "type": 35665
        },
        "accessor_296": {
            "bufferView": "bufferView_484",
            "byteOffset": 886,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_298": {
            "bufferView": "bufferView_484",
            "byteOffset": 1174,
            "byteStride": 12,
            "count": 134,
            "max": [
                81,
                133,
                40
            ],
            "min": [
                61,
                21,
                20
            ],
            "type": 35665
        },
        "accessor_300": {
            "bufferView": "bufferView_484",
            "byteOffset": 2782,
            "byteStride": 12,
            "count": 134,
            "max": [
                0.965927,
                1,
                0.965926
            ],
            "min": [
                -0.965927,
                -1,
                -0.965928
            ],
            "type": 35665
        },
        "accessor_316": {
            "bufferView": "bufferView_484",
            "byteOffset": 1963,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_318": {
            "bufferView": "bufferView_484",
            "byteOffset": 2251,
            "byteStride": 12,
            "count": 111,
            "max": [
                471,
                133,
                -60
            ],
            "min": [
                451,
                21,
                -80.0002
            ],
            "type": 35665
        },
        "accessor_320": {
            "bufferView": "bufferView_484",
            "byteOffset": 3583,
            "byteStride": 12,
            "count": 111,
            "max": [
                0.96593,
                1,
                0.965926
            ],
            "min": [
                -0.96593,
                -1,
                -0.965927
            ],
            "type": 35665
        },
        "accessor_336": {
            "bufferView": "bufferView_484",
            "byteOffset": 2930,
            "byteStride": 0,
            "count": 144,
            "type": 5123
        },
        "accessor_338": {
            "bufferView": "bufferView_484",
            "byteOffset": 3218,
            "byteStride": 12,
            "count": 111,
            "max": [
                580.784,
                133,
                -17.2157
            ],
            "min": [
                567.216,
                21,
                -30.7846
            ],
            "type": 35665
        },
        "accessor_340": {
            "bufferView": "bufferView_484",
            "byteOffset": 4550,
            "byteStride": 12,
            "count": 111,
            "max": [
                0.965929,
                1,
                0.965926
            ],
            "min": [
                -0.965933,
                -1,
                -0.965927
            ],
            "type": 35665
        },
        "accessor_356": {
            "bufferView": "bufferView_484",
            "byteOffset": 3791,
            "byteStride": 0,
            "count": 192,
            "type": 5123
        },
        "accessor_358": {
            "bufferView": "bufferView_484",
            "byteOffset": 4175,
            "byteStride": 12,
            "count": 131,
            "max": [
                870,
                116.659,
                -19.0001
            ],
            "min": [
                40,
                94.3591,
                -66
            ],
            "type": 35665
        },
        "accessor_36": {
            "bufferView": "bufferView_484",
            "byteOffset": 9271,
            "byteStride": 0,
            "count": 402,
            "type": 5123
        },
        "accessor_360": {
            "bufferView": "bufferView_484",
            "byteOffset": 5747,
            "byteStride": 12,
            "count": 131,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_376": {
            "bufferView": "bufferView_484",
            "byteOffset": 4739,
            "byteStride": 0,
            "count": 624,
            "type": 5123
        },
        "accessor_378": {
            "bufferView": "bufferView_484",
            "byteOffset": 5987,
            "byteStride": 12,
            "count": 336,
            "max": [
                870,
                60.0005,
                -19.4418
            ],
            "min": [
                -6.134,
                38.4962,
                -89.7372
            ],
            "type": 35665
        },
        "accessor_38": {
            "bufferView": "bufferView_484",
            "byteOffset": 10075,
            "byteStride": 12,
            "count": 175,
            "max": [
                567.998,
                115.667,
                114.256
            ],
            "min": [
                34.9992,
                102.632,
                -18.965
            ],
            "type": 35665
        },
        "accessor_380": {
            "bufferView": "bufferView_484",
            "byteOffset": 10019,
            "byteStride": 12,
            "count": 336,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_396": {
            "bufferView": "bufferView_484",
            "byteOffset": 6593,
            "byteStride": 0,
            "count": 420,
            "type": 5123
        },
        "accessor_398": {
            "bufferView": "bufferView_484",
            "byteOffset": 7433,
            "byteStride": 12,
            "count": 262,
            "max": [
                896.38,
                85.8985,
                47
            ],
            "min": [
                39.0001,
                68.5375,
                -100
            ],
            "type": 35665
        },
        "accessor_40": {
            "bufferView": "bufferView_484",
            "byteOffset": 12175,
            "byteStride": 12,
            "count": 175,
            "max": [
                0.999992,
                1,
                0.999754
            ],
            "min": [
                -0.999687,
                -1,
                -1
            ],
            "type": 35665
        },
        "accessor_400": {
            "bufferView": "bufferView_484",
            "byteOffset": 10577,
            "byteStride": 12,
            "count": 262,
            "max": [
                1,
                1,
                1
            ],
            "min": [
                -1,
                -1,
                -0.999914
            ],
            "type": 35665
        },
        "accessor_416": {
            "bufferView": "bufferView_484",
            "byteOffset": 8127,
            "byteStride": 0,
            "count": 258,
            "type": 5123
        },
        "accessor_418": {
            "bufferView": "bufferView_484",
            "byteOffset": 8643,
            "byteStride": 12,
            "count": 116,
            "max": [
                67.8099,
                30.1709,
                -23.7172
            ],
            "min": [
                4.81924,
                5.35e-05,
                -58.0517
            ],
            "type": 35665
        },
        "accessor_420": {
            "bufferView": "bufferView_484",
            "byteOffset": 10035,
            "byteStride": 12,
            "count": 116,
            "max": [
                0.996547,
                1,
                0.996207
            ],
            "min": [
                -0.924274,
                -1,
                -0.996196
            ],
            "type": 35665
        },
        "accessor_436": {
            "bufferView": "bufferView_484",
            "byteOffset": 10604,
            "byteStride": 0,
            "count": 180,
            "type": 5123
        },
        "accessor_438": {
            "bufferView": "bufferView_484",
            "byteOffset": 10964,
            "byteStride": 12,
            "count": 127,
            "max": [
                542.806,
                45.2273,
                19.4956
            ],
            "min": [
                31.5023,
                27.4832,
                -55.9644
            ],
            "type": 35665
        },
        "accessor_440": {
            "bufferView": "bufferView_484",
            "byteOffset": 12488,
            "byteStride": 12,
            "count": 127,
            "max": [
                0.907578,
                1,
                0.995805
            ],
            "min": [
                -0.995805,
                -1,
                -0.995805
            ],
            "type": 35665
        },
        "accessor_456": {
            "bufferView": "bufferView_484",
            "byteOffset": 11623,
            "byteStride": 0,
            "count": 180,
            "type": 5123
        },
        "accessor_458": {
            "bufferView": "bufferView_484",
            "byteOffset": 11983,
            "byteStride": 12,
            "count": 129,
            "max": [
                542.806,
                27.2358,
                19.4956
            ],
            "min": [
                31.5023,
                9.49172,
                -55.9644
            ],
            "type": 35665
        },
        "accessor_460": {
            "bufferView": "bufferView_484",
            "byteOffset": 13531,
            "byteStride": 12,
            "count": 129,
            "max": [
                0.907577,
                1,
                0.995805
            ],
            "min": [
                -0.995805,
                -1,
                -0.995805
            ],
            "type": 35665
        },
        "accessor_476": {
            "bufferView": "bufferView_484",
            "byteOffset": 12657,
            "byteStride": 0,
            "count": 1422,
            "type": 5123
        },
        "accessor_478": {
            "bufferView": "bufferView_484",
            "byteOffset": 15501,
            "byteStride": 12,
            "count": 415,
            "max": [
                896.379,
                30,
                100
            ],
            "min": [
                -9.16e-05,
                -3.66e-05,
                -100
            ],
            "type": 35665
        },
        "accessor_480": {
            "bufferView": "bufferView_484",
            "byteOffset": 20481,
            "byteStride": 12,
            "count": 415,
            "max": [
                1,
                1,
                0.999914
            ],
            "min": [
                -1,
                -1,
                -0.999907
            ],
            "type": 35665
        },
        "accessor_56": {
            "bufferView": "bufferView_484",
            "byteOffset": 15065,
            "byteStride": 0,
            "count": 606,
            "type": 5123
        },
        "accessor_58": {
            "bufferView": "bufferView_484",
            "byteOffset": 16277,
            "byteStride": 12,
            "count": 284,
            "max": [
                473.564,
                60.062,
                125.258
            ],
            "min": [
                42,
                38.5,
                -34.4626
            ],
            "type": 35665
        },
        "accessor_60": {
            "bufferView": "bufferView_484",
            "byteOffset": 19685,
            "byteStride": 12,
            "count": 284,
            "max": [
                0.999962,
                1,
                0.999881
            ],
            "min": [
                -0.999962,
                -1,
                -0.999762
            ],
            "type": 35665
        },
        "accessor_76": {
            "bufferView": "bufferView_484",
            "byteOffset": 16904,
            "byteStride": 0,
            "count": 792,
            "type": 5123
        },
        "accessor_78": {
            "bufferView": "bufferView_484",
            "byteOffset": 18488,
            "byteStride": 12,
            "count": 322,
            "max": [
                877.529,
                60.1002,
                119.956
            ],
            "min": [
                446.906,
                38.3163,
                -29.7362
            ],
            "type": 35665
        },
        "accessor_80": {
            "bufferView": "bufferView_484",
            "byteOffset": 22352,
            "byteStride": 12,
            "count": 322,
            "max": [
                0.993806,
                1,
                0.999748
            ],
            "min": [
                -0.999452,
                -1,
                -0.99904
            ],
            "type": 35665
        },
        "accessor_96": {
            "bufferView": "bufferView_484",
            "byteOffset": 19097,
            "byteStride": 0,
            "count": 1422,
            "type": 5123
        },
        "accessor_98": {
            "bufferView": "bufferView_484",
            "byteOffset": 21941,
            "byteStride": 12,
            "count": 415,
            "max": [
                896.379,
                30,
                100
            ],
            "min": [
                -9.16e-05,
                -3.66e-05,
                -100
            ],
            "type": 35665
        }
    },
    "animations": {},
    "asset": {
        "generator": "collada2gltf@484bc37fe4fa8c5974618e65b311e7b22be95381",
        "premultipliedAlpha": true,
        "profile": "WebGL 1.0.2",
        "version": 0.6
    },
    "bufferViews": {
        "bufferView_481": {
            "buffer": "SwissArmyKnife",
            "byteLength": 0,
            "byteOffset": 0
        },
        "bufferView_482": {
            "buffer": "SwissArmyKnife",
            "byteLength": 0,
            "byteOffset": 0,
            "target": 34963
        },
        "bufferView_483": {
            "buffer": "SwissArmyKnife",
            "byteLength": 0,
            "byteOffset": 0,
            "target": 34962
        },
        "bufferView_484": {
            "buffer": "compression",
            "byteLength": 40646,
            "byteOffset": 0
        }
    },
    "buffers": {
        "compression": {
            "byteLength": 40646,
            "path": "compression.bin",
            "type": "arraybuffer"
        }
    },
    "materials": {
        "ID108": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        0.964706,
                        0.545098,
                        0,
                        1
                    ]
                }
            },
            "name": "GOLD_METAL1"
        },
        "ID156": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        0.360784,
                        0.360784,
                        0.360784,
                        1
                    ]
                }
            },
            "name": "GREY_PLASTIC1"
        },
        "ID42": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        1,
                        0,
                        0,
                        1
                    ]
                }
            },
            "name": "RED_PLASTIC1"
        },
        "ID8": {
            "instanceTechnique": {
                "technique": "technique0",
                "values": {
                    "diffuse": [
                        1,
                        1,
                        1,
                        1
                    ]
                }
            },
            "name": "STAINLESS_METAL1"
        }
    },
    "meshes": {
        "ID106": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 0,
                        "count": 886,
                        "floatAttributesIndexes": {},
                        "indicesCount": 144,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 98
                    }
                }
            },
            "name": "ID106",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_280",
                        "POSITION": "accessor_278"
                    },
                    "indices": "accessor_276",
                    "material": "ID108",
                    "primitive": 4
                }
            ]
        },
        "ID114": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 886,
                        "count": 1077,
                        "floatAttributesIndexes": {},
                        "indicesCount": 144,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 134
                    }
                }
            },
            "name": "ID114",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_300",
                        "POSITION": "accessor_298"
                    },
                    "indices": "accessor_296",
                    "material": "ID108",
                    "primitive": 4
                }
            ]
        },
        "ID120": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 1963,
                        "count": 967,
                        "floatAttributesIndexes": {},
                        "indicesCount": 144,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 111
                    }
                }
            },
            "name": "ID120",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_320",
                        "POSITION": "accessor_318"
                    },
                    "indices": "accessor_316",
                    "material": "ID108",
                    "primitive": 4
                }
            ]
        },
        "ID126": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 2930,
                        "count": 861,
                        "floatAttributesIndexes": {},
                        "indicesCount": 144,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 111
                    }
                }
            },
            "name": "ID126",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_340",
                        "POSITION": "accessor_338"
                    },
                    "indices": "accessor_336",
                    "material": "ID108",
                    "primitive": 4
                }
            ]
        },
        "ID134": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 3791,
                        "count": 948,
                        "floatAttributesIndexes": {},
                        "indicesCount": 192,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 131
                    }
                }
            },
            "name": "ID134",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_360",
                        "POSITION": "accessor_358"
                    },
                    "indices": "accessor_356",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID140": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 4739,
                        "count": 1854,
                        "floatAttributesIndexes": {},
                        "indicesCount": 624,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 336
                    }
                }
            },
            "name": "ID140",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_380",
                        "POSITION": "accessor_378"
                    },
                    "indices": "accessor_376",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID146": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 6593,
                        "count": 1534,
                        "floatAttributesIndexes": {},
                        "indicesCount": 420,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 262
                    }
                }
            },
            "name": "ID146",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_400",
                        "POSITION": "accessor_398"
                    },
                    "indices": "accessor_396",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID154": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 8127,
                        "count": 1144,
                        "floatAttributesIndexes": {},
                        "indicesCount": 258,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 116
                    }
                }
            },
            "name": "ID154",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_420",
                        "POSITION": "accessor_418"
                    },
                    "indices": "accessor_416",
                    "material": "ID156",
                    "primitive": 4
                }
            ]
        },
        "ID16": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 9271,
                        "count": 1333,
                        "floatAttributesIndexes": {},
                        "indicesCount": 402,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 175
                    }
                }
            },
            "name": "ID16",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_40",
                        "POSITION": "accessor_38"
                    },
                    "indices": "accessor_36",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID162": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 10604,
                        "count": 1019,
                        "floatAttributesIndexes": {},
                        "indicesCount": 180,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 127
                    }
                }
            },
            "name": "ID162",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_440",
                        "POSITION": "accessor_438"
                    },
                    "indices": "accessor_436",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID168": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 11623,
                        "count": 1034,
                        "floatAttributesIndexes": {},
                        "indicesCount": 180,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 129
                    }
                }
            },
            "name": "ID168",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_460",
                        "POSITION": "accessor_458"
                    },
                    "indices": "accessor_456",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID176": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 12657,
                        "count": 2408,
                        "floatAttributesIndexes": {},
                        "indicesCount": 1422,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 415
                    }
                }
            },
            "name": "ID176",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_480",
                        "POSITION": "accessor_478"
                    },
                    "indices": "accessor_476",
                    "material": "ID42",
                    "primitive": 4
                }
            ]
        },
        "ID24": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 15065,
                        "count": 1839,
                        "floatAttributesIndexes": {},
                        "indicesCount": 606,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 284
                    }
                }
            },
            "name": "ID24",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_60",
                        "POSITION": "accessor_58"
                    },
                    "indices": "accessor_56",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID32": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 16904,
                        "count": 2193,
                        "floatAttributesIndexes": {},
                        "indicesCount": 792,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 322
                    }
                }
            },
            "name": "ID32",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_80",
                        "POSITION": "accessor_78"
                    },
                    "indices": "accessor_76",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID40": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 19097,
                        "count": 2452,
                        "floatAttributesIndexes": {},
                        "indicesCount": 1422,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 415
                    }
                }
            },
            "name": "ID40",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_100",
                        "POSITION": "accessor_98"
                    },
                    "indices": "accessor_96",
                    "material": "ID42",
                    "primitive": 4
                }
            ]
        },
        "ID50": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 21549,
                        "count": 1585,
                        "floatAttributesIndexes": {},
                        "indicesCount": 360,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 240
                    }
                }
            },
            "name": "ID50",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_120",
                        "POSITION": "accessor_118"
                    },
                    "indices": "accessor_116",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID56": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 23134,
                        "count": 1832,
                        "floatAttributesIndexes": {},
                        "indicesCount": 438,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 317
                    }
                }
            },
            "name": "ID56",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_140",
                        "POSITION": "accessor_138"
                    },
                    "indices": "accessor_136",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID6": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 24966,
                        "count": 1404,
                        "floatAttributesIndexes": {},
                        "indicesCount": 426,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 191
                    }
                }
            },
            "name": "ID6",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_20",
                        "POSITION": "accessor_18"
                    },
                    "indices": "accessor_16",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID62": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 26370,
                        "count": 1878,
                        "floatAttributesIndexes": {},
                        "indicesCount": 468,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 321
                    }
                }
            },
            "name": "ID62",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_160",
                        "POSITION": "accessor_158"
                    },
                    "indices": "accessor_156",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID68": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 28248,
                        "count": 1096,
                        "floatAttributesIndexes": {},
                        "indicesCount": 192,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 127
                    }
                }
            },
            "name": "ID68",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_180",
                        "POSITION": "accessor_178"
                    },
                    "indices": "accessor_176",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID74": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 29344,
                        "count": 1835,
                        "floatAttributesIndexes": {},
                        "indicesCount": 438,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 317
                    }
                }
            },
            "name": "ID74",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_200",
                        "POSITION": "accessor_198"
                    },
                    "indices": "accessor_196",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID82": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 31179,
                        "count": 3867,
                        "floatAttributesIndexes": {},
                        "indicesCount": 3948,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 689
                    }
                }
            },
            "name": "ID82",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_220",
                        "POSITION": "accessor_218"
                    },
                    "indices": "accessor_216",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID90": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 35046,
                        "count": 1983,
                        "floatAttributesIndexes": {},
                        "indicesCount": 630,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 303
                    }
                }
            },
            "name": "ID90",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_240",
                        "POSITION": "accessor_238"
                    },
                    "indices": "accessor_236",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        },
        "ID98": {
            "extensions": {
                "Open3DGC-compression": {
                    "compressedData": {
                        "bufferView": "bufferView_484",
                        "byteOffset": 37029,
                        "count": 3617,
                        "floatAttributesIndexes": {},
                        "indicesCount": 1020,
                        "mode": "binary",
                        "type": 5121,
                        "verticesCount": 634
                    }
                }
            },
            "name": "ID98",
            "primitives": [
                {
                    "attributes": {
                        "NORMAL": "accessor_260",
                        "POSITION": "accessor_258"
                    },
                    "indices": "accessor_256",
                    "material": "ID8",
                    "primitive": 4
                }
            ]
        }
    },
    "nodes": {
        "ID104": {
            "children": [
                "ID105"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_2"
        },
        "ID105": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID106",
                "ID114",
                "ID120",
                "ID126"
            ],
            "name": "SHAFTS"
        },
        "ID132": {
            "children": [
                "ID133"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_3"
        },
        "ID133": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID134",
                "ID140",
                "ID146"
            ],
            "name": "SPRINGS"
        },
        "ID14": {
            "children": [
                "ID15"
            ],
            "matrix": [
                0.865,
                0.499399,
                -0.0487418,
                0,
                -0.499993,
                0.86603,
                8.1e-06,
                0,
                0.0422159,
                0.0243636,
                0.998811,
                0,
                290.871,
                -383.28,
                -38.2665,
                1
            ],
            "name": "BLADE_SMALL"
        },
        "ID15": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID16"
            ],
            "name": "BLADE_SMALL"
        },
        "ID152": {
            "children": [
                "ID153"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "TWEEZER"
        },
        "ID153": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID154",
                "ID162",
                "ID168"
            ],
            "name": "TWEEZER"
        },
        "ID174": {
            "children": [
                "ID175"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                0.5,
                -0.866025,
                0,
                0,
                0,
                0,
                1,
                0,
                206.113,
                -254.305,
                0,
                1
            ],
            "name": "instance_4"
        },
        "ID175": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID176"
            ],
            "name": "COVERPLATE"
        },
        "ID2": {
            "children": [
                "ID3"
            ],
            "matrix": [
                0.90446,
                -0.18283,
                0.385389,
                0,
                0.42532,
                0.317773,
                -0.847422,
                0,
                0.0324683,
                0.930373,
                0.365175,
                0,
                -138.625,
                430.166,
                -338.318,
                1
            ],
            "name": "Swiss_Army_Knife"
        },
        "ID22": {
            "children": [
                "ID23"
            ],
            "matrix": [
                0.854885,
                0.493568,
                0.159881,
                0,
                -0.5,
                0.866026,
                -1e-07,
                0,
                -0.138461,
                -0.0799404,
                0.987136,
                0,
                262.54,
                -399.638,
                -64.5054,
                1
            ],
            "name": "BOTTLE_OPENER"
        },
        "ID23": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID24"
            ],
            "name": "BOTTLE_OPENER"
        },
        "ID3": {
            "children": [
                "ID4",
                "ID14",
                "ID22",
                "ID30",
                "ID38",
                "ID48",
                "ID80",
                "ID88",
                "ID96",
                "ID104",
                "ID132",
                "ID152",
                "ID174"
            ],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "name": "Swiss_Army_Knife"
        },
        "ID30": {
            "children": [
                "ID31"
            ],
            "matrix": [
                0.864628,
                0.499193,
                -0.0567967,
                0,
                -0.5,
                0.866026,
                -2e-07,
                0,
                0.0491872,
                0.0283985,
                0.998386,
                0,
                280.808,
                -389.091,
                22.006,
                1
            ],
            "name": "CAN_OPENER"
        },
        "ID31": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID32"
            ],
            "name": "CAN_OPENER"
        },
        "ID38": {
            "children": [
                "ID39"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_0"
        },
        "ID39": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID40"
            ],
            "name": "COVERPLATE"
        },
        "ID4": {
            "children": [
                "ID5"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                270.068,
                -395.282,
                -25.9493,
                1
            ],
            "name": "BLADE_MAIN"
        },
        "ID48": {
            "children": [
                "ID49"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "instance_1"
        },
        "ID49": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID50",
                "ID56",
                "ID62",
                "ID68",
                "ID74"
            ],
            "name": "DIVIDER"
        },
        "ID5": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID6"
            ],
            "name": "BLADE_MAIN"
        },
        "ID80": {
            "children": [
                "ID81"
            ],
            "matrix": [
                0.866025,
                0.5,
                -0,
                0,
                -0.5,
                0.866025,
                -0,
                0,
                0,
                0,
                1,
                0,
                283.151,
                -387.738,
                0,
                1
            ],
            "name": "KEY_RING"
        },
        "ID81": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID82"
            ],
            "name": "KEY_RING"
        },
        "ID88": {
            "children": [
                "ID89"
            ],
            "matrix": [
                0.865919,
                0.499938,
                0.0157073,
                0,
                -0.5,
                0.866025,
                -1e-07,
                0,
                -0.013603,
                -0.0078536,
                0.999877,
                0,
                339.411,
                -355.256,
                50.6871,
                1
            ],
            "name": "REEMER"
        },
        "ID89": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID90"
            ],
            "name": "REEMER"
        },
        "ID96": {
            "children": [
                "ID97"
            ],
            "matrix": [
                0.858419,
                0.495605,
                0.132256,
                0,
                -0.499998,
                0.866027,
                6e-07,
                0,
                -0.114537,
                -0.0661284,
                0.991216,
                0,
                262.207,
                -399.02,
                -94.0762,
                1
            ],
            "name": "SAW"
        },
        "ID97": {
            "children": [],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "meshes": [
                "ID98"
            ],
            "name": "SAW"
        },
        "node_0": {
            "children": [
                "ID2"
            ],
            "matrix": [
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                1
            ],
            "name": "SketchUp"
        }
    },
    "programs": {
        "program_0": {
            "attributes": [
                "a_normal",
                "a_position"
            ],
            "fragmentShader": "SwissArmyKnife0FS",
            "vertexShader": "SwissArmyKnife0VS"
        }
    },
    "scene": "defaultScene",
    "scenes": {
        "defaultScene": {
            "nodes": [
                "node_0"
            ]
        }
    },
    "shaders": {
        "SwissArmyKnife0FS": {
            "path": "SwissArmyKnife0FS.glsl",
            "type": 35632
        },
        "SwissArmyKnife0VS": {
            "path": "SwissArmyKnife0VS.glsl",
            "type": 35633
        }
    },
    "skins": {},
    "techniques": {
        "technique0": {
            "parameters": {
                "diffuse": {
                    "type": 35666
                },
                "modelViewMatrix": {
                    "semantic": "MODELVIEW",
                    "type": 35676
                },
                "normal": {
                    "semantic": "NORMAL",
                    "type": 35665
                },
                "normalMatrix": {
                    "semantic": "MODELVIEWINVERSETRANSPOSE",
                    "type": 35675
                },
                "position": {
                    "semantic": "POSITION",
                    "type": 35665
                },
                "projectionMatrix": {
                    "semantic": "PROJECTION",
                    "type": 35676
                }
            },
            "pass": "defaultPass",
            "passes": {
                "defaultPass": {
                    "details": {
                        "commonProfile": {
                            "extras": {
                                "doubleSided": false
                            },
                            "lightingModel": "Lambert",
                            "parameters": [
                                "diffuse",
                                "modelViewMatrix",
                                "normalMatrix",
                                "projectionMatrix"
                            ]
                        },
                        "type": "COLLADA-1.4.1/commonProfile"
                    },
                    "instanceProgram": {
                        "attributes": {
                            "a_normal": "normal",
                            "a_position": "position"
                        },
                        "program": "program_0",
                        "uniforms": {
                            "u_diffuse": "diffuse",
                            "u_modelViewMatrix": "modelViewMatrix",
                            "u_normalMatrix": "normalMatrix",
                            "u_projectionMatrix": "projectionMatrix"
                        }
                    },
                    "states": {
                        "blendEnable": 0,
                        "cullFaceEnable": 1,
                        "depthMask": 1,
                        "depthTestEnable": 1
                    }
                }
            }
        }
    }
}})